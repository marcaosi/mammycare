const utils = {
    api: 'http://mammycare.progm.net.br/server/api/'
    //api: 'http://localhost/mammycare/api/'
}

export default utils