import React, { Component } from 'react';
import './home.css'
class Home extends Component {
  render() {
    return (
      <div className="row margin">
        <div className="col-12 text-center">
          <p>Aplicativo para Prevenção, Avaliação e Condutas Terapêuticas dos Traumas Mamilares na Lactação</p>
        </div>
      </div>
    );
  }
}

export default Home;
