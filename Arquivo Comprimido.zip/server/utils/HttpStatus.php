<?php
abstract class HttpStatus{
    public static $BAD_REQUEST = 400;
    public static $SUCCESS = 200;
    public static $BAD_SERVER = 500;
    public static $NOT_FOUND = 404;
    public static $NO_CONTENT = 203;
    public static $CREATED = 202;
    public static $FORBIDDEN = 403;
}